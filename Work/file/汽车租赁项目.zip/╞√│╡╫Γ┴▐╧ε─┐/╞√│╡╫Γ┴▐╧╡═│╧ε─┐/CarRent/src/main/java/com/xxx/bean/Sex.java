package com.xxx.bean;

public class Sex {
    private String nv;

    public String getNv() {
        return nv;
    }

    public void setNv(String nv) {
        this.nv = nv;
    }
}
